java -jar target/*.jar --spring.profiles.active=prod &

package com.edenhub.gateway.domain.enumeration;

/**
 * The EnumActionStatus enumeration.
 */
public enum SMSTemplate {
    REGISTER,
    RESTPASSWORD,
    CHANGEPASSWORD,
    CHANGEACCOUNT
}

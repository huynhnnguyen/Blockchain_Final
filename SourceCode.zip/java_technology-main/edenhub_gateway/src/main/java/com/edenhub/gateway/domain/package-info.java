/**
 * JPA domain objects.
 */
package com.edenhub.gateway.domain;

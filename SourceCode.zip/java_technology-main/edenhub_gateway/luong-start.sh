java -jar target/*.jar --spring.profiles.active=dev &

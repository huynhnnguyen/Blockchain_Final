package com.example.apiDemo.domain.enumeration;

public enum Status {
    LEARNING,

    DROP,

    PAUSE
}

INSERT INTO public."role"
(id, created_by, created_date, last_modified_by, last_modified_date, code, value)
VALUES(2, 'anonymousUser', '2023-09-15 21:39:56.372', 'anonymousUser', '2023-09-15 21:39:56.372', 'ROLE_CONSUMER', 'consumer');
INSERT INTO public."role"
(id, created_by, created_date, last_modified_by, last_modified_date, code, value)
VALUES(1, 'anonymousUser', '2023-09-15 21:39:56.372', 'anonymousUser', '2023-09-15 21:39:56.372', 'ROLE_ADMIN', 'quan li');

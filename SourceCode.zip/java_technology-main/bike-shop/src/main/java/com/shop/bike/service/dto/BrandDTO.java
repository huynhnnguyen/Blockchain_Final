package com.shop.bike.service.dto;

import lombok.Data;

@Data
public class BrandDTO {
	private Long id;
	
	private String name;
}

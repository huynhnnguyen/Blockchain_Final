package com.shop.bike.entity.enumeration;

public enum MediaType {
	IMAGE, VIDEO, AUDIO
}

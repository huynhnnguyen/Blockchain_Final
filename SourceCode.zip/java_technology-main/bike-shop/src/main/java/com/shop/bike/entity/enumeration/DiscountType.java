package com.shop.bike.entity.enumeration;

/**
 * The DiscountType enumeration.
 */
public enum DiscountType {
    TRADE,
    CASH,
}

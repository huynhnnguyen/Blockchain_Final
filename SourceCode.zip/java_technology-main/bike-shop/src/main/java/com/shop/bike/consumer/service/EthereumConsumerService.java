package com.shop.bike.consumer.service;

import com.shop.bike.consumer.dto.ProfileConsumerDTO;
import com.shop.bike.consumer.dto.RegisterConsumerDTO;
import com.shop.bike.consumer.vm.ProfileConsumerVM;
import com.shop.bike.service.EthereumService;
import com.shop.bike.service.UserService;

public interface EthereumConsumerService extends EthereumService {
	

}

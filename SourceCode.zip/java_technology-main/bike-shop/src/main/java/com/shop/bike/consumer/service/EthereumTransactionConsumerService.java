package com.shop.bike.consumer.service;

import com.shop.bike.service.EthereumService;
import com.shop.bike.service.EthereumTransactionService;

public interface EthereumTransactionConsumerService extends EthereumTransactionService {
	

}

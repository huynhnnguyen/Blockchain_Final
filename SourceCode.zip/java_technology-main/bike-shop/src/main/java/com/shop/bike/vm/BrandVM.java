package com.shop.bike.vm;

import lombok.Data;

@Data
public class BrandVM {
	
	private Long id;
	
	private String name;
	
	private String shortName;
	
	private String description;
}

package com.shop.bike.admin.vm;

import lombok.Data;

@Data
public class ProductAttributeVM {
	
	private Long id;
	
	private String name;
	
	private String value;
}

package com.shop.bike.consumer.vm;

import com.shop.bike.vm.UserVM;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class ProfileConsumerVM extends UserVM {
}

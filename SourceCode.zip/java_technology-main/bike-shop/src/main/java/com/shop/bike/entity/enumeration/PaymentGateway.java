package com.shop.bike.entity.enumeration;

public enum PaymentGateway {
	VISA,
	MOMO,
	NAPAS
}

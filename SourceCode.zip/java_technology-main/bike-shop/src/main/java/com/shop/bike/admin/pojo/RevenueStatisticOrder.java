package com.shop.bike.admin.pojo;

public interface RevenueStatisticOrder {


}

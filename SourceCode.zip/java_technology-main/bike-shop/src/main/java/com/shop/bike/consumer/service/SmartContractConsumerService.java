package com.shop.bike.consumer.service;

import com.shop.bike.service.SmartContractService;

public interface SmartContractConsumerService extends SmartContractService {
	

}

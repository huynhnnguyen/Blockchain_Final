package com.shop.bike.entity.enumeration;

public enum StatusOrder {
    ACCEPTED,
    WAITING,
	CANCELED
}

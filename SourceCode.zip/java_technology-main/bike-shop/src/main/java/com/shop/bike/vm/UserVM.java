package com.shop.bike.vm;

import lombok.Data;

@Data
public class UserVM {
	
	private Long id;
	
	private String email;
	
	private String name;
	
	private String phone;
}

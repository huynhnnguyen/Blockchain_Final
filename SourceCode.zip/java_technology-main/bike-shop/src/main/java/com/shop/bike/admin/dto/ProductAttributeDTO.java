package com.shop.bike.admin.dto;

import lombok.Data;

@Data
public class ProductAttributeDTO {
	
	private String name;
	
	private String value;
}

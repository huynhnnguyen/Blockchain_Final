package com.shop.bike.entity.enumeration;

public enum CouponStatus {
	
	ACTIVATED,
	
	DEACTIVATED,
	
	EXPIRED,
	
	DELETED,
	
}

package com.shop.bike.consumer.service;

import com.shop.bike.service.MiningEthereumService;

public interface MiningEthereumConsumerService extends MiningEthereumService {
	

}

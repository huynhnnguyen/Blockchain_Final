package com.shop.bike.consumer.service;

import com.shop.bike.service.SmartContractService;
import com.shop.bike.service.WalletService;

public interface WalletConsumerService extends WalletService {
	

}

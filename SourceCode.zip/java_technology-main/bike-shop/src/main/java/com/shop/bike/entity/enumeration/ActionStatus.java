package com.shop.bike.entity.enumeration;

public enum ActionStatus {
	
	DELETED,
	ACTIVATED,
	DEACTIVATED
}
